# FastAPI server entry point
