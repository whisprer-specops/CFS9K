# Card Fraud Simulator 9000™ (CFS9K)

## 🔧 How to Use

1. `cd backend && pip install -r requirements.txt`
2. `bash ../launch.sh`
3. Play around in `frontend/index.html` or `honeyshoppe.html`

## 🚩 Features

- Fake card fraud simulator
- Simulated crypto laundering
- Graph visualizations
- Honeypot shop page
- Fingerprinting engine
- Detonate mode (`--ghost`)

## 💥 Detonate Mode

Run with `--ghost` to:
- Erase logs
- Trigger honeypots
- Simulate tamper alerts

---

Have fun and don't use this for evil, fren ✌️
