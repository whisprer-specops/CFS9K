#!/bin/bash
echo "Starting CFS9K..."
cd backend
uvicorn main:app --reload &
sleep 2
xdg-open ../frontend/index.html || open ../frontend/index.html
