
from fastapi import FastAPI, Request
import json
from safe_mode import check_blacklisted_mixer

app = FastAPI()

@app.post("/launder")
async def launder_card(request: Request):
    data = await request.json()
    mixer_name = data.get("mixer", "UnknownMixer")
    flagged, info = check_blacklisted_mixer(mixer_name)
    if flagged:
        return {
            "status": "⚠️ Blacklisted mixer detected!",
            "mixer": mixer_name,
            "reason": info["status"]
        }
    return {
        "status": "✅ Simulated laundering completed.",
        "mixer": mixer_name,
        "hops": ["wallet1", "wallet2", "clean_wallet"]
    }
