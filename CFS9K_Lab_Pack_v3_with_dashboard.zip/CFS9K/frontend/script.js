
function simulateLaunder() {
  const mixer = document.getElementById("mixerName").value;
  fetch("http://localhost:8000/launder", {
    method: "POST",
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ mixer: mixer })
  }).then(res => res.json()).then(data => {
    alert(data.status + "\nMixer: " + data.mixer + (data.reason ? "\nReason: " + data.reason : ""));
  });
}
