
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi_socketio import SocketManager
from safe_mode import check_blacklisted_mixer

app = FastAPI()
sio = SocketManager(app=app)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.post("/launder")
async def launder_card(request: Request):
    data = await request.json()
    mixer_name = data.get("mixer", "UnknownMixer")
    flagged, info = check_blacklisted_mixer(mixer_name)

    if flagged:
        result = {
            "status": "Suspicious",
            "mixer": mixer_name,
            "reason": info["status"],
            "response": "Flagged and logged"
        }
        await sio.emit("suspicious_activity", result)
        return result

    clean_result = {
        "status": "OK",
        "mixer": mixer_name,
        "hops": ["wallet1", "wallet2", "clean_wallet"]
    }
    await sio.emit("normal_activity", clean_result)
    return clean_result
