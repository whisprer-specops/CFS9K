#!/bin/bash
echo "Starting CFS9K Backend..."
cd backend
uvicorn main:app --reload --host 0.0.0.0 --port 8000 &
sleep 2
echo "Opening monitoring dashboard..."
xdg-open ../frontend/monitor.html || open ../frontend/monitor.html
